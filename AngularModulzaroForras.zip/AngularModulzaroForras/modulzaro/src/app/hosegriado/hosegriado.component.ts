import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})
export class HosegriadoComponent {
 ho!:number;
  AktualisRiadoSzint(hofok:number):string{

    if(hofok<=25){
     return "0.szintű hőségridaó volt elrendelve";
  }

  else if(hofok<=27){
    return " 1.szintű hőségridaó volt elrendelve";
  }
  else if(hofok<=29){
    return " 3.szintű hőségridaó volt elrendelve";
  }

  else if(hofok<=32){
    return " 4.szintű hőségridaó volt elrendelve";
  }

  else{
      return "hibás adat";
  }
}

  EredmenyKiiro():string{
   if(this.AktualisRiadoSzint(this.ho)){
     return "Az aktuális hőségriadó szintje:"
   }
   else{
     return""
   }
  }

  eredmenyek:string=this.EredmenyKiiro();

  EredmenyMentes(){
   if(this.AktualisRiadoSzint(this.ho)){
     this.eredmenyListazo.push(`Az aktuális hőségriadó szintje: ${this.ho} szintű`);
   }

  }
  eredmenyListazo:string[]=[];
}

